# install
### npm install

# run
### npx mix watch
#
### dist/app.css - libs
### dist/style.css - pages style