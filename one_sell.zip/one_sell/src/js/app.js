
let burger = document.querySelector(".burgerHeader") ;
let medianavdiv = document.querySelectorAll(".mediaNav ul li") ;
let nav = document.querySelector(".mediaNav") ;
let x = document.querySelector(".mediaNav1 img")
let userOpen = document.querySelector(".select")

let mediaHeader = document.querySelector(".mediaHeader")
let headerDiv = document.querySelector(".headerDiv")
let userIcon = document.querySelector(".userIcon")
function burgerfunc(){
    
    burger.addEventListener("click", function(){
        nav.classList.add("mediaNavflex")
        burger.style.display = "none";
    })
    x.addEventListener("click",function(){
        burger.style.display = "block"
        nav.classList.remove("mediaNavflex")
    })
    userIcon.addEventListener("click",function(){
       mediaHeader.classList.toggle("mediaHeaderFlex")
        
    })
    
    userOpen.addEventListener("click",function(){
        mediaHeader.classList.toggle("mediaHeaderFlex")
       
    })
   
}
burgerfunc()